# ALSP

Vicente Lineros Pardo

## Notas

El codigo esta pesimamente optimizado y tiene fugas graves de memoria.

El codigo actualmente implementa Tabu Search con un tamaño propocional a
la instancia y 5000 iteraciones. Aunque en algunos casos luego de la 70000 aun encuentra
soluciones mejores a la actual.

